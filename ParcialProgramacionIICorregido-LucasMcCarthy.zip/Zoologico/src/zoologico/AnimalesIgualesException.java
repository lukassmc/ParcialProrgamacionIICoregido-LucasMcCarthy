package Zoologico;

public class AnimalesIgualesException extends Exception{
    public AnimalesIgualesException(String mensaje){
        super(mensaje);
    }
    
}
