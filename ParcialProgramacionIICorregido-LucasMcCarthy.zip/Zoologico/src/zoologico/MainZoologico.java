package Zoologico;

public class MainZoologico {
    public static void main(String[] args) throws Exception {

       Menu menuzoologico = new Menu();
       
       menuzoologico.iniciar();
    }
}
