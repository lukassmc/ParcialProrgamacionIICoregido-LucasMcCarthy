package Zoologico;

public enum Dieta {
    CARNIVORO,
    HERBIVORO,
    OMNIVORO
}
