package Zoologico;

public class Ave extends Animales implements Vacunable {
    private double envergaduraAlas;


    public Ave(String nombre, int edad, double peso, Dieta dieta, double envergaduraAlas) {
        super(nombre, edad, peso, dieta);
        this.envergaduraAlas = envergaduraAlas;
     
    }

    @Override
    public void vacunar() {
        System.out.println(nombre + " ha sido vacunado.");
    }


    @Override
    public String toString() {
        return "Ave [envergaduraAlas=" + envergaduraAlas + "]";
    }

    





}
