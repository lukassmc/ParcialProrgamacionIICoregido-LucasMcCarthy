
package Zoologico;

public interface Vacunable {
   
    public void vacunar();
}
