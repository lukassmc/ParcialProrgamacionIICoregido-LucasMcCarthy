package Zoologico;

public class Mamifero extends Animales implements Vacunable{
  
    public Mamifero(String nombre, int edad, double peso, Dieta dieta) {
        super(nombre, edad, peso, dieta);
  
    }

    @Override
    public void vacunar() {
        System.out.println(nombre + " ha sido vacunado.");
    }

    @Override
    public String toString() {
        return "Mamifero [peso=" + peso + ", dieta=" + dieta + "]";
    }

    
    
}
