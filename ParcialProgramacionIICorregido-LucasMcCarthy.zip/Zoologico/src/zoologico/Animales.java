package Zoologico;

import java.util.Objects;

public abstract class Animales {

    
    protected String nombre;
    protected int edad;
    protected double peso;
    protected Dieta dieta;


    public Animales(String nombre, int edad, double peso, Dieta dieta) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.dieta = dieta;
    }
    
    public String getNombre() {
        return nombre;
    }


    @Override
    public String toString() {
        return "Animales [nombre=" + nombre + ", edad=" + edad + ", peso=" + peso + ", dieta=" + dieta + "]\n";
    }



    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Animales other = (Animales) obj;
        if (nombre == null) {
            if (other.nombre != null)
                return false;
        } else if (!nombre.equals(other.nombre))
            return false;
        if (edad != other.edad)
            return false;
        return true;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.nombre);
        hash = 71 * hash + this.edad;
        return hash;
    }

}
