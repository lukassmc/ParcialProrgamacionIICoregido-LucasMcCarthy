package Zoologico;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    private Zoologico zoologico;
    private ArrayList<Animales> animalesParaAgregar;
    private Scanner scanner;

    public Menu() {
        this.zoologico = null;
        this.animalesParaAgregar = new ArrayList<>();
        this.scanner = new Scanner(System.in);
    }

    public void iniciar() {
        int opcion = 0;
        do {
            limpiarConsola();
            mostrarMenu();
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    crearZoologico();
                    break;
                case 2:
                    crearAnimalesMenu();
                    break;
                case 3:
                    agregarAnimalesAlZoo();
                    break;
                case 4:
                    zoologico.mostrarAnimales();
                    break;
                case 5:
                    zoologico.vacunarAnimales();
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente nuevamente.");
            }
            if (opcion != 6) {
                System.out.println("\nPresione Enter para continuar...");
                scanner.nextLine(); 
            }
        } while (opcion != 6);
    }

    private void limpiarConsola() {
        for (int i = 0; i < 50; i++) {
            System.out.println();
        }
    }

    private void mostrarMenu() {
        System.out.println("\n=== MENU ===");
        System.out.println("1. Crear Zoologico");
        System.out.println("2. Crear Animales");
        System.out.println("3. Agregar Animales al Zoologico");
        System.out.println("4. Mostrar Animales en el Zoologico");
        System.out.println("5. Vacunar Animales");
        System.out.println("6. Salir");
        System.out.print("Seleccione una opcion: ");
    }

    private void crearZoologico() {
        if (zoologico == null) {
            zoologico = new Zoologico();
            System.out.println("Zoologico creado exitosamente.");
        } else {
            System.out.println("El zoologico ya ha sido creado.");
        }
    }

private void crearAnimalesMenu() {
    if (zoologico == null) {
        System.out.println("Primero debes crear el zoológico.");
        return;
    }


    Mamifero elefante = new Mamifero("Elefante", 17, 114.7, Dieta.HERBIVORO);
    Mamifero tigre = new Mamifero("Tigre", 5, 220.5, Dieta.CARNIVORO);
    Mamifero elefante2 = new Mamifero("Elefante", 17, 114.7, Dieta.HERBIVORO);

    Ave cuervo = new Ave("Cuervo", 2, 1.54, Dieta.OMNIVORO, 123);
    Ave loro = new Ave("Loro", 3, 0.8, Dieta.OMNIVORO, 50);
    Ave aguila = new Ave("Aguila", 4, 3.0, Dieta.CARNIVORO, 180);

    Reptil dragonDeComodo = new Reptil("DragonDeComodo", 5, 57.6, Dieta.CARNIVORO, Escamas.GRANULARES, "ectotermia");
    Reptil iguana = new Reptil("Iguana", 4, 2.5, Dieta.HERBIVORO, Escamas.AQUILLADAS, "ectotermia");
    Reptil dragonDeComodo2 = new Reptil("DragonDeComodo", 5, 57.6, Dieta.CARNIVORO, Escamas.GRANULARES, "ectotermia");


    animalesParaAgregar.add(elefante);
    animalesParaAgregar.add(tigre);
    animalesParaAgregar.add(elefante2);
    animalesParaAgregar.add(cuervo);
    animalesParaAgregar.add(loro);
    animalesParaAgregar.add(aguila);
    animalesParaAgregar.add(dragonDeComodo);
    animalesParaAgregar.add(iguana);
    animalesParaAgregar.add(dragonDeComodo2);

    System.out.println("Animales creados. Puedes agregarlos al zoologico cuando quieras.");
}

 private void agregarAnimalesAlZoo() {
    if (zoologico == null) {
        System.out.println("Primero debes crear el zoologico.");
        return;
    }

    if (animalesParaAgregar.isEmpty()) {
        System.out.println("No hay animales creados. Usa la opción 'Crear Animales' primero.");
        return;
    }

    for (Animales animal : animalesParaAgregar) {
        try {
            zoologico.agregarAnimales(animal);
            System.out.println(animal.getNombre() + " agregado al zoologico.");
        } catch (AnimalesIgualesException e) {
            System.out.println(e.getMessage());  
        }
    }
   
    animalesParaAgregar.clear();
 }

}
    


